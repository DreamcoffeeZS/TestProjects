//
//  LGAFNetworkingManger.h
//  LGNetworkManager
//
//  Created by ws on 2020/11/11.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LGAFNetworkingManager : NSObject
+ (instancetype)manager;
@end

NS_ASSUME_NONNULL_END
